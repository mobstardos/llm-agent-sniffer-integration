Задача:
{query}

Контекст:
{context}
