# Sprint 1.A Patch — Decompose src/main.py (Stage A: Foundation)

> Первая часть декомпозиции `src/main.py` (рекомендация 1).
> Создаёт **фундамент** (state.py + app.py + первые 3 роутера), на
> котором в Sprint 1.B-1.D будет построен полный перенос 86 эндпоинтов.

## Что в патче (6 файлов + патч + тесты)

```
sprint1A-patch/
├── src/
│   ├── state.py                 ← AppState dataclass + get_*() Depends()
│   ├── app.py                   ← FastAPI app + lifespan (вынесен)
│   └── routes/
│       ├── __init__.py          ← пустой пакет
│       ├── static.py            ← 5 эндпоинтов: /, /favicon, /analytics, /guide, /metrics
│       ├── cache.py             ← 1 эндпоинт: GET /api/cache/stats
│       └── features.py          ← 1 эндпоинт: GET /api/features
├── patches/
│   └── 0001-main-py-decomposition-stage-A.patch  ← тонкий main.py
├── tests/
│   └── test_sprint1a_state_and_routes.py          ← 8 кейсов
├── SPRINT-ROADMAP.xlsx          ← рекомендация 1: "Sprint 1.A готов (5/16 роутеров)"
└── README.md                    ← этот файл
```

## Что делает Stage A

| Компонент | LOC | Что |
|---|---|---|
| `src/state.py` | 130 | `AppState` dataclass (15 Optional полей: cache, policies, llm, memory, registry, mcp, orchestrator, plans, supervisor, journal, micro_worker, features_loader, pg_replicator, agent_memory_indexer, age_store/age_sync, backup_manager, ws_clients, local_chat_active_until, started_at). `get_*()` dependency functions (10 шт): get_policies, get_llm, get_memory, get_registry, get_mcp, get_orchestrator, get_plans, get_journal, get_features_loader, get_cache, get_supervisor. |
| `src/app.py` | 270 | `app = FastAPI(lifespan=lifespan)`. lifespan разбит на 7 шагов: `_init_pg_autodetect`, `_init_cache_and_policies`, `_init_llm_and_memory`, `_init_registry_and_mcp`, `_init_loop_and_orchestrator`, `_init_journal_and_background`, `_init_features_and_replicator`, `_init_ws_bridge`. Shutdown в обратном порядке через `_shutdown()`. Static mounts: `/static` и `/features`. |
| `src/routes/__init__.py` | 12 | Документация пакета + план Sprint 1.B. |
| `src/routes/static.py` | 65 | 5 эндпоинтов: `GET /` (index.html), `GET /favicon.ico` (SVG), `GET /analytics`, `GET /guide`, `GET /metrics` (Prometheus). |
| `src/routes/cache.py` | 25 | 1 эндпоинт: `GET /stats` → `{"enabled": ..., **cache.stats()}`. Uses `Depends(get_cache)`. |
| `src/routes/features.py` | 30 | 1 эндпоинт: `GET /features` → `{"features": [...], "events": events.recent(30)}`. Uses `Depends(get_features_loader)`. |
| **Патч `0001`** | — | Меняет `src/main.py`: (1) импортирует `app` из `src.app`, (2) удаляет `state: dict = {}` и заменяет на `from src.state import state`, (3) добавляет совместимость через `state_compat: dict` для legacy-кода, (4) удаляет 5+1+1 эндпоинтов (static + cache + features), (5) меняет entry point на `uvicorn.run("src.app:app", ...)`. |

## Стратегия gradual refactoring (важно!)

**НЕ удаляем эндпоинты из main.py сразу** — иначе система сломается.
Стратегия:

1. **Stage A (этот патч)**: создать фундамент (state + app + 3 простейших роутера), сделать main.py тонким (импорт + совместимость). **Все 80 оставшихся эндпоинтов остаются в main.py**.

2. **Stage B (Sprint 1.B, ~5-7 дней)**: перенос по одной функциональной группе, от простой к сложной:
   - plans, models, sessions, project, features (по 1-2 эндпоинта)
   - database, enrichment, graph, search, backup (3-7 эндпоинтов)
   - analytics (10 эндпоинтов)
   - policies (12 эндпоинтов)
   - registry (25 эндпоинтов)
   - chats (3 эндпоинта)

   После каждой группы — smoke-тест: `curl http://127.0.0.1:8000/api/<group>` должен вернуть тот же ответ, что и до рефакторинга.

3. **Stage C (Sprint 1.C, ~3-4 дня)**: вынос WebSocket `/ws` (~480 строк) в `src/ws/chat.py`.

4. **Stage D (Sprint 1.D, ~2-3 дня)**: cleanup — удалить из main.py все перенесённые функции, оставить только точку входа (≤30 строк).

**Целевое состояние**: `src/main.py` ≤ 30 строк (точка входа + uvicorn.run).

## Порядок применения

```bash
# 0. Предполагается, что Sprint 1, 2, 3 патчи уже применены.
# (Stage A — это отдельный патч для рекомендации 1.)

# 1. Распаковать Sprint 1.A:
cd /path/to/llm-agent
unzip /path/to/llm-agent-final-sprint1A-patch.zip -d .

# 2. Скопировать новые файлы (не перезаписывая существующие):
cp sprint1A-patch/src/state.py src/state.py
cp sprint1A-patch/src/app.py src/app.py
mkdir -p src/routes
cp -r sprint1A-patch/src/routes/* src/routes/
cp -r sprint1A-patch/tests/test_sprint1a_state_and_routes.py tests/

# 3. Применить патч к main.py (НЕ перезаписывать — git apply):
git apply sprint1A-patch/patches/0001-main-py-decomposition-stage-A.patch

# 4. Прогнать smoke-тест:
python run.py
# Сервер должен стартовать; проверить 3 эндпоинта:
curl -i http://127.0.0.1:8000/                    # ← из routes/static.py
curl -i http://127.0.0.1:8000/favicon.ico         # ← из routes/static.py
curl -i http://127.0.0.1:8000/api/cache/stats     # ← из routes/cache.py
curl -i http://127.0.0.1:8000/api/features        # ← из routes/features.py

# 5. Прогнать тесты Sprint 1.A:
pytest tests/test_sprint1a_state_and_routes.py -v
# Ожидается: 8 кейсов зелёные

# 6. Закоммитить:
git add -A
git commit -m "refactor: Sprint 1.A — state.py + app.py + 3 first routers (static, cache, features)"
```

## Статус после Stage A

| Метрика | Было (Sprint 4-5) | После Stage A |
|---|---|---|
| `src/main.py` | 2 640 строк | ~2 580 строк (5 эндпоинтов перенесено) |
| `src/state.py` | — | 130 строк (новый) |
| `src/app.py` | — | 270 строк (новый) |
| `src/routes/__init__.py` | — | 12 строк (новый) |
| `src/routes/static.py` | — | 65 строк (5 эндпоинтов) |
| `src/routes/cache.py` | — | 25 строк (1 эндпоинт) |
| `src/routes/features.py` | — | 30 строк (1 эндпоинт) |
| Endpoints в main.py | 86 | 80 (перенесено 5+1+1) |
| Endpoints в routes/ | 0 | 7 (static + cache + features) |
| Тест-кейсов | 50 (Sprint 3) | 58 (+8 для Sprint 1.A) |

## Риски и миграции

| Риск | Митигация |
|---|---|
| **`feature_loader.mount(app, state_dict)`** — ожидает dict, а мы передаём AppState | `_state_as_dict()` в app.py оборачивает AppState в dict для обратной совместимости. В Sprint 1.B — обновить FeatureLoader.mount() принять AppState. |
| **`state.get("...")` в legacy-коде** — `dataclass.get()` не существует | `state_compat: dict` + `_sync_state_to_compat()` мост. В Sprint 1.B заменяем все `state.get("...")` на `state.<field>` через grep+sed. |
| **Порядок инициализации в lifespan** — изменился | Тот же порядок: PG → cache → policies → llm → memory → registry → mcp → loop → orchestrator → journal → background → features → replicator. Проверено в `_init_*` функциях. |
| **WebSocket handler** остался в main.py | Не проблема для Stage A — он работает. В Stage C перенесём в `src/ws/chat.py`. |
| **`from src.app import app`** может создать цикл импортов (app → state → routes → app?) | Нет — state.py и routes/*.py НЕ импортируют app.py. app.py импортирует state + routes последним. |
| **`@app.get(...)` декораторы в main.py** — после `from src.app import app` они применяются к тому же объекту | Да, это работает — FastAPI app — синглтон, декораторы можно применять из разных модулей. В Stage B-D заменим на `@router.get(...)` и `app.include_router()`. |

## Критерии готовности Stage A

- [x] `src/state.py` ≤ 130 строк (dataclass + 11 get_*() функций)
- [x] `src/app.py` ≤ 280 строк (FastAPI app + lifespan + 7 _init_* helpers)
- [x] `src/routes/__init__.py` существует
- [x] `src/routes/static.py` регистрирует 5 эндпоинтов
- [x] `src/routes/cache.py` регистрирует 1 эндпоинт
- [x] `src/routes/features.py` регистрирует 1 эндпоинт
- [x] 8 unit-тестов для state и routes
- [ ] `python run.py` стартует без ошибок (требует ручной проверки)
- [ ] `curl http://127.0.0.1:8000/` возвращает 200 (требует ручной проверки)
- [ ] `curl http://127.0.0.1:8000/api/cache/stats` возвращает `{"enabled": ...}`
- [ ] `curl http://127.0.0.1:8000/api/features` возвращает `{"features": [...], "events": [...]}`

## Что осталось (Sprint 1.B-1.D)

| Stage | Длительность | Что | Endpoints |
|---|---|---|---|
| **1.A** (этот патч) | готов | state + app + static/cache/features | 7/86 |
| **1.B** | 5-7 дней | plans, models, sessions, project, database, enrichment, graph, search, backup, analytics, policies, registry, chats | +73/86 (всего 80) |
| **1.C** | 3-4 дня | WebSocket `/ws` handler (~480 строк) → `src/ws/chat.py` | +1 WS |
| **1.D** | 2-3 дня | Cleanup, удаление legacy helpers из main.py | 86/86 |

**Целевое состояние** (после 1.D): `src/main.py` ≤ 30 строк (точка входа).

## Связанные документы

- `docs/MAIN-PY-DECOMPOSITION-PLAN.md` (Sprint 1 patch) — полный план.
- `SPRINT-ROADMAP.xlsx` — обновлённый статус рекомендации 1.
- Sprint 2 patch: `mypy.ini` (strict для `src/state.py` будет добавлен в Sprint 1.B).
- Sprint 3 patch: `tests/conftest.py` (FakeLLM, FakeRuntime используются и в новых тестах).
