#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════
# APPLY_ALL.sh — применяет все 7 патчей в правильном порядке
# ═══════════════════════════════════════════════════════════════════════
#
# Использование:
#   cd /path/to/llm-agent  # корень проекта (где README.md)
#   bash APPLY_ALL.sh           # применить все
#   bash APPLY_ALL.sh --dry-run # только показать, что будет
#
# Порядок (КРИТИЧНО):
#   1. Sprint 1 — профили + docs (P0)
#   2. Sprint 2 — pre-commit + mypy + assert + requirements pin (P1)
#   3. Sprint 3 — unit-тесты (P1)
#   4. Sprint 4-5 — Docker + SECURITY + print→logging + skeleton + mcp test (P2)
#   5. Sprint 1.A — state.py + app.py + 3 роутера (этап декомпозиции main.py)
#   6. Sprint 1.B — 13 роутеров, 73 эндпоинта (продолжение декомпозиции)
#   7. Sprint 1.C+D — WS handler + slim main.py (финал декомпозиции)
#
# После применения: 14/14 рекомендаций выполнено. main.py: 2640 → 47 строк.
# ═══════════════════════════════════════════════════════════════════════

set -euo pipefail

DRY_RUN=false
[[ "${1:-}" == "--dry-run" ]] && DRY_RUN=true && echo "🔍 DRY RUN — изменения не применяются"

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
[[ ! -f README.md ]] && {
    echo "❌ Не найден README.md — запускайте из корня llm-agent"
    exit 1
}

PATCHES_DIR="${PATCHES_DIR:-$ROOT/llm-agent-master-patch}"
[[ ! -d "$PATCHES_DIR" ]] && {
    # Fallback: ищем рядом
    PATCHES_DIR="$ROOT"
}

apply_step() {
    local step=$1 sprint=$2
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "[$step] Sprint $sprint"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    local dir="$PATCHES_DIR/sprint${sprint}-patch"
    [[ ! -d "$dir" ]] && dir="$PATCHES_DIR/sprint${sprint,,}-patch"
    if $DRY_RUN; then
        echo "  [DRY] применил бы $dir/*"
        return 0
    fi
    # Копируем файлы (создаём нужные подкаталоги)
    if [[ -d "$dir/data" ]]; then
        mkdir -p data && cp -rn "$dir/data/"* data/ 2>/dev/null || true
    fi
    if [[ -d "$dir/docs" ]]; then
        mkdir -p docs && cp -rn "$dir/docs/"* docs/ 2>/dev/null || true
    fi
    if [[ -d "$dir/src" ]]; then
        mkdir -p src/routes src/ws
        cp -rn "$dir/src/"* src/ 2>/dev/null || true
    fi
    if [[ -d "$dir/.github" ]]; then
        mkdir -p .github/workflows
        cp -rn "$dir/.github/"* .github/ 2>/dev/null || true
    fi
    if [[ -d "$dir/.pre-commit" ]]; then
        cp -rn "$dir/.pre-commit/"* .pre-commit/ 2>/dev/null || true
    fi
    if [[ -f "$dir/.pre-commit-config.yaml" ]]; then
        cp "$dir/.pre-commit-config.yaml" .
    fi
    if [[ -f "$dir/mypy.ini" ]]; then
        cp "$dir/mypy.ini" .
    fi
    if [[ -f "$dir/requirements-dev.txt" ]]; then
        cp "$dir/requirements-dev.txt" .
    fi
    if [[ -f "$dir/requirements.pinned.txt" ]]; then
        cp "$dir/requirements.pinned.txt" .
    fi
    if [[ -f "$dir/Dockerfile" ]]; then
        cp "$dir/Dockerfile" .
        cp "$dir/.dockerignore" .
    fi
    if [[ -f "$dir/docker-compose.patch.yml" ]]; then
        cp "$dir/docker-compose.patch.yml" .
    fi
    if [[ -f "$dir/ruff.toml" ]]; then
        cp "$dir/ruff.toml" .
    fi
    if [[ -d "$dir/features" ]]; then
        mkdir -p features
        cp -rn "$dir/features/"* features/ 2>/dev/null || true
    fi
    if [[ -d "$dir/scripts" ]]; then
        mkdir -p scripts
        cp -rn "$dir/scripts/"* scripts/ 2>/dev/null || true
    fi
    if [[ -d "$dir/tests" ]]; then
        cp -rn "$dir/tests/"* tests/ 2>/dev/null || true
    fi
    if [[ -f "$dir/new_main.py" ]]; then
        cp "$dir/new_main.py" .
    fi
    # Patch-файлы (git apply)
    if [[ -d "$dir/patches" ]]; then
        for p in "$dir/patches"/*.patch; do
            [[ -f "$p" ]] || continue
            git apply "$p" 2>/dev/null || echo "  ⚠ patch не применился: $(basename "$p") (возможно уже применён)"
        done
    fi
    echo "  ✓ Sprint $sprint applied"
}

# ─── Применяем в порядке ────────────────────────────────────────────
apply_step 1 "1"        # профили + docs
apply_step 2 "2"        # pre-commit + mypy + assert + requirements
apply_step 3 "3"        # unit-тесты
apply_step 4 "4-5"      # Docker + SECURITY + print + skeleton + mcp test
apply_step 5 "1A"       # state.py + app.py + 3 роутера
apply_step 6 "1B"       # 13 роутеров, 73 эндпоинта
apply_step 7 "1CD"      # WS handler + slim main.py

# ─── Финальные шаги ──────────────────────────────────────────────────
if ! $DRY_RUN; then
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "✅ Все 7 спринтов применены"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    echo "Финальные шаги:"
    echo "  1. Установить dev-зависимости:"
    echo "     pip install -r requirements-dev.txt"
    echo "  2. Применить требования к коду (если ещё не сделано):"
    echo "     cp requirements.pinned.txt requirements.txt"
    echo "  3. Smoke-тест:"
    echo "     python run.py"
    echo "     curl http://127.0.0.1:8000/api/db/health"
    echo "  4. Прогнать все тесты:"
    echo "     pytest tests/ -v --tb=short"
    echo "  5. Git commit:"
    echo "     git add -A"
    echo "     git commit -m 'release: v2026-10-01 — full refactoring + production-ready'"
    echo ""
    echo "Документация:"
    echo "  - RELEASE_NOTES.md — changelog + миграция"
    echo "  - DEPLOYMENT_GUIDE.md — production deployment"
    echo "  - POST-MORTEM.pdf — итоговый отчёт о трансформации"
fi
