# -*- coding: utf-8 -*-
"""Патч к src/app.py — добавляет include_router() для 13 новых роутеров Sprint 1.B.

Применить к уже существующему src/app.py (созданному в Sprint 1.A).
После этого все 86 эндпоинтов (минус WS /ws, который перенесётся в Sprint 1.C)
работают из src/routes/ — main.py остаётся только тонкой точкой входа.
"""

# ─── ДОБАВИТЬ в src/app.py после строки "app.include_router(routes_features.router, ...)" ──

# Sprint 1.B: добавить регистрацию всех 13 новых роутеров
from src.routes import plans as routes_plans                # noqa: E402
from src.routes import models as routes_models              # noqa: E402
from src.routes import sessions as routes_sessions          # noqa: E402
from src.routes import project as routes_project            # noqa: E402
from src.routes import database as routes_database          # noqa: E402
from src.routes import enrichment as routes_enrichment      # noqa: E402
from src.routes import graph as routes_graph                # noqa: E402
from src.routes import search as routes_search              # noqa: E402
from src.routes import backup as routes_backup              # noqa: E402
from src.routes import analytics as routes_analytics       # noqa: E402
from src.routes import policies as routes_policies         # noqa: E402
from src.routes import chats as routes_chats                # noqa: E402
from src.routes import registry as routes_registry         # noqa: E402

# Регистрация роутеров (prefix/tag заданы внутри каждого модуля)
app.include_router(routes_plans.router)            # prefix=/api/plans
app.include_router(routes_models.router)           # prefix=/api/model
app.include_router(routes_sessions.router)        # prefix=/api/sessions
app.include_router(routes_project.router)         # prefix=/api/project
app.include_router(routes_database.router)        # prefix=/api/db
app.include_router(routes_enrichment.router)      # prefix=/api/enrichment
app.include_router(routes_graph.router)           # prefix=/api/{age,cdc}
app.include_router(routes_search.router)          # prefix=/api/{search,synonyms}
app.include_router(routes_backup.router)          # prefix=/api/backup
app.include_router(routes_analytics.router)       # prefix=/api/analytics
app.include_router(routes_policies.router)        # prefix=/api/policies
app.include_router(routes_chats.router)           # prefix=/api/{chats,digest}
app.include_router(routes_registry.router)        # prefix=/api/registry

# ИТОГО после Sprint 1.B: зарегистрировано 16 роутеров (3 из Stage A +
# 13 из Stage B), что покрывает 80 эндпоинтов из 86. Оставшиеся 6 — это
# WebSocket /ws (Sprint 1.C) и 5 static endpoints (уже в routes/static.py
# из Stage A). Sprint 1.D: удалить из main.py весь legacy-код.
