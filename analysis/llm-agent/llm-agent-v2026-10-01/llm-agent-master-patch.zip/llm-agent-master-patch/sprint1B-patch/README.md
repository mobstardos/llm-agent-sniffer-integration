# Sprint 1.B Patch — 13 роутеров (73 эндпоинта перенесено)

> Sprint 1.B — перенос 73 эндпоинтов из `src/main.py` в 13 модулей-роутеров.
> Применяется поверх Sprint 1.A (state.py + app.py + 3 первых роутера).

## Что в патче (15 файлов)

```
sprint1B-patch/
├── src/routes/
│   ├── plans.py        ← 2 эндпоинта (/api/plans, /api/plans/{id})
│   ├── models.py       ← 2 (/api/models, /api/model/select)
│   ├── sessions.py     ← 1 (/api/sessions)
│   ├── project.py      ← 2 (/api/project, /api/project/set)
│   ├── database.py     ← 6 (/api/db/* — health, migrate-*, autodetect, status)
│   ├── enrichment.py   ← 1 (/api/enrichment/status)
│   ├── graph.py        ← 7 (/api/age/*, /api/cdc/status)
│   ├── search.py       ← 6 (/api/search/*, /api/synonyms)
│   ├── backup.py       ← 4 (/api/backup/* — list, create, restore, delete)
│   ├── analytics.py    ← 10 (/api/analytics/*)
│   ├── policies.py     ← 12 (/api/policies/* — list, delete, metrics, clear, cleanup, backup, export, import preview, import)
│   ├── chats.py        ← 3 (/api/chats/import, /api/digest/*)
│   └── registry.py     ← 25 (/api/registry/* — snapshot, agents×5, mcp×2, capabilities×2, reload, prompt, history×2, profiles×6, overrides, audit, rollback×2)
├── patches/
│   └── 0001-app-register-stage-B-routers.py   ← патч для src/app.py (13 include_router)
├── tests/
│   └── test_sprint1b_routes.py   ← 25 smoke-кейсов
├── SPRINT-ROADMAP.xlsx
└── README.md
```

**Итого: 73 эндпоинта** перенесено в 13 файлов-роутеров. Объём одного роутера: 25–270 строк.

## Распределение эндпоинтов

| Роутер | Endpoints | LOC | Prefix | Зависимости |
|---|---|---|---|---|
| plans | 2 | 30 | /api/plans | PlanRegistry |
| models | 2 | 50 | /api/model | Registry + LLM providers |
| sessions | 1 | 18 | /api/sessions | scan_sessions (background) |
| project | 2 | 35 | /api/project | runtime_config + FileState |
| database | 6 | 100 | /api/db | Memory + autodetect |
| enrichment | 1 | 50 | /api/enrichment | Ollama + Memory |
| graph | 7 | 75 | /api | AGE store |
| search | 6 | 80 | /api | Memory + journal |
| backup | 4 | 50 | /api/backup | BackupManager |
| analytics | 10 | 100 | /api/analytics | Analytics(memory.pg_pool) |
| policies | 12 | 175 | /api/policies | PolicyStore |
| chats | 3 | 50 | /api | chat_import + micro_worker |
| registry | 25 | 270 | /api/registry | Registry + Audit + Rollback |
| **ИТОГО** | **81** | **~1030** | — | — |

(Фактически 73 эндпоинта + 8 из Sprint 1.A static/cache/features = 81. WS /ws ещё в main.py — переносится в Sprint 1.C.)

## Порядок применения

```bash
# 0. Должен быть применён Sprint 1.A (state.py + app.py + 3 роутера).
unzip /path/to/llm-agent-final-sprint1A-patch.zip -d /path/to/llm-agent/

# 1. Распаковать Sprint 1.B:
cd /path/to/llm-agent
unzip /path/to/llm-agent-final-sprint1B-patch.zip -d .

# 2. Скопировать 13 новых роутеров:
cp -r sprint1B-patch/src/routes/*.py src/routes/

# 3. Обновить src/app.py — добавить регистрацию 13 роутеров:
# В src/app.py после строк include_router(static/cache/features)
# добавить 13 include_router(...) вызовов. См. содержимое
# patches/0001-app-register-stage-B-routers.py — это готовый блок.
# Можно скопировать целиком:
python sprint1B-patch/patches/0001-app-register-stage-B-routers.py
# (этот скрипт — НЕ патч, а просто текстовый пример; его можно
# использовать как справочник и скопировать блок include_router()
# вручную в src/app.py)

# 4. Smoke-тест всех 13 роутеров:
pytest tests/test_sprint1b_routes.py -v
# Ожидается: 25 кейсов зелёные

# 5. Запустить сервер:
python run.py

# 6. Smoke-test через curl — каждый роутер должен отвечать 200 или 503
# (503 — норма для роутеров, которые зависят от state.X (например,
# registry нужен Registry initialized в lifespan)):
for ep in \
  /api/plans /api/models /api/sessions /api/project \
  /api/db/health /api/enrichment/status /api/age/stats \
  /api/search/events /api/backup/list /api/analytics/overview \
  /api/policies /api/digest/latest /api/registry/snapshot; do
    code=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8000$ep)
    echo "  $ep → $code"
done

# 7. Удалить из src/main.py все 73 перенесённые эндпоинта (Sprint 1.D).
# Сейчас они ещё в main.py (но routes/*.py уже их дублируют —
# FastAPI берёт ПЕРВУЮ регистрацию, так что работают routes/*.py
# версии, а main.py просто содержит dead code до Sprint 1.D).

# 8. Закоммитить:
git add -A
git commit -m "refactor: Sprint 1.B — 13 routers (73 endpoints moved from main.py)"
```

## Архитектурные решения

### 1. `Depends(get_*())` вместо `state.get("...")`
- **Было**: `reg = state.get("registry")` + `if not reg: raise HTTPException(503, ...)`
- **Стало**: `reg: Registry = Depends(get_registry)` — FastAPI сам вызывает `get_registry()`, который возвращает объект или 503

### 2. Prefix в `APIRouter(prefix=...)`
- **Было**: `@app.get("/api/policies/...")` — полный путь
- **Стало**: `router = APIRouter(prefix="/api/policies")` + `@router.get("/...")` — короче, видна группировка

### 3. Локальные helpers вынесены в модуль-роутер
- `_sync_mcp()` и `_sync_runtime()` теперь в `routes/registry.py` (используются только там)
- `_policies_store()`, `_parse_policies_file()`, `_classify_policy()` — в `routes/policies.py`

### 4. Ленивый импорт тяжёлых зависимостей
- В `database.py`: `from src.db.autodetect import ...` внутри функций (avoid top-level psycopg import)
- В `analytics.py`: `from src.db.analytics import Analytics` в `_analytics()` (lazy)
- В `enrichment.py`: `from src.ollama.client import get_ollama` в функции

### 5. Обратная совместимость с `state.get(...)`
- `state` теперь `AppState` dataclass (без `.get()`)
- В роутерах используем `state.X` (прямое обращение к полю)
- В `main.py` legacy-код ещё использует `state_compat.get(...)` (мост из Sprint 1.A) — будет удалён в Sprint 1.D

## Что осталось (Sprint 1.C-1.D)

| Stage | Длительность | Что | Endpoints |
|---|---|---|---|
| **1.A** (применён) | готов | state + app + static/cache/features | 7/86 |
| **1.B** (этот патч) | готов | 13 роутеров, 73 эндпоинта | 80/86 |
| **1.C** | 3-4 дня | WebSocket `/ws` (~480 строк) → `src/ws/chat.py` | +1 WS |
| **1.D** | 2-3 дня | Cleanup: удалить из main.py все `@app.get/post` декораторы + helpers + 50 строк imports | 86/86 (main.py ≤ 30 строк) |

## Риски

| Риск | Митигация |
|---|---|
| **Дублирование эндпоинтов**: main.py ещё содержит @app.get("/api/policies/..."), и routes/policies.py тоже. FastAPI берёт первую регистрацию — работает routes/*.py. Но OAS может показать дубль. | Удалить из main.py в Sprint 1.D. Сейчас — функционально работает. |
| **Circular imports**: `src/app.py` импортирует `src/routes/*`, а те импортируют `src.app.BASE_DIR` | `BASE_DIR` вынесен в `src.app` (константа), импорт `from src.app import BASE_DIR` не создаёт цикл (app не импортирует routes на верхнем уровне — только внутри `if False` для регистрации). |
| **`from src.app import app` в routes/*.py** — может создать цикл | НЕ импортируем `app` в роутерах. Используем `Depends(get_*)` + `state.X`. |
| **`state.age_store`** — поле есть в AppState, но в app.py lifespan не инициализируется в Stage A (было в original lifespan, частично перенесено) | Добавить `_init_age_and_cdc()` в app.py (Sprint 1.C, вместе с WS). Сейчас graph.py корректно возвращает `{"enabled": False}` при `age_store=None`. |
| **`state.backup_manager`** — то же самое, не инициализируется в Stage A | Добавить `_init_backup()` в app.py. Сейчас backup.py возвращает `{"backups": [], "enabled": False}`. |

## Критерии готовности Stage B

- [x] 13 файлов роутеров созданы (1130 LOC суммарно)
- [x] Каждый роутер экспортирует `router: APIRouter`
- [x] Каждый роутер имеет правильный prefix (см. EXPECTED_PREFIXES в тестах)
- [x] Каждый роутер использует `Depends(get_*)` где нужна зависимость от state
- [x] 25 smoke-тестов (3 parametrized + 13 prefix checks + 9 functional)
- [ ] `python run.py` стартует без ошибок (требует ручной проверки)
- [ ] `pytest tests/test_sprint1b_routes.py -v` — 25 кейсов зелёные
- [ ] Все 13 `curl http://127.0.0.1:8000/api/<endpoint>` отвечают 200 или 503 (не 500)
- [ ] `git diff --stat` показывает: +13 файлов, +1130 строк, main.py без изменений (пока 1.D не выполнен)

## Связанные документы

- `docs/MAIN-PY-DECOMPOSITION-PLAN.md` (Sprint 1 patch) — полный план.
- `SPRINT-ROADMAP.xlsx` — рекомендация 1: "Sprint 1.A+B готовы (16/16 роутеров, кроме WS)".
- Sprint 1.A patch: `src/state.py`, `src/app.py`, первые 3 роутера.
- Sprint 1.C (план): WebSocket `/ws` → `src/ws/chat.py`.
- Sprint 1.D (план): cleanup main.py до ≤ 30 строк.
