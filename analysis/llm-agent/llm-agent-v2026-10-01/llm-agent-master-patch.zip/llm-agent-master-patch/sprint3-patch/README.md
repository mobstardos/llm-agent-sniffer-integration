# Sprint 3 Patch — llm-agent (P1: Test Coverage)

> Скелеты тестов для рекомендации 7. Применяется поверх Sprint 1 + Sprint 2.

## Что в патче

```
sprint3-patch/
├── tests/
│   ├── conftest.py                 ← общие фикстуры (env_no_pg, FakeLLM, FakeRuntime, FakeMCP)
│   ├── test_orchestrator.py        ← 11 кейсов: route() + handle()
│   ├── test_llm_client.py          ← 13 кейсов: chat() + fallback + _client_for
│   ├── test_journal_recorder.py    ← 10 кейсов: before/after_tool_call + truncate + redact
│   ├── test_memory_facade.py       ← 10 кейсов: initialize + search + stats + cleanup
│   └── README.md                   ← как запускать, что покрыто, что НЕ покрыто
├── SPRINT-ROADMAP.xlsx             ← обновлённый: P0 2/3, P1 5/5 готово, P2 0/6
└── README.md                       ← этот файл
```

**Итого: 44 тест-кейса** в 4 модулях + conftest.py.

## Порядок применения

```bash
# 0. Предполагается, что Sprint 1 и Sprint 2 патчи уже применены:
unzip /path/to/llm-agent-final-sprint1-patch.zip -d /path/to/llm-agent/
unzip /path/to/llm-agent-final-sprint2-patch.zip -d /path/to/llm-agent/

# 1. Распаковать Sprint 3:
unzip /path/to/llm-agent-final-sprint3-patch.zip -d /path/to/llm-agent/

# 2. Установить dev-зависимости (если ещё не установлены):
cd /path/to/llm-agent
pip install -r requirements-dev.txt

# 3. Установить пакет в editable-режиме (для импортов src.*):
pip install -e .

# 4. Прогнать тесты локально:
pytest tests/ -v --tb=short

# Ожидается: большинство тестов зелёные. Некоторые могут падать —
# см. раздел "Известные проблемы" в tests/README.md. Цель Sprint 3 —
# создать каркас, а не 100% зелёный CI.

# 5. С покрытием:
pytest tests/ --cov=src --cov-report=term-missing
```

## Стратегия покрытия

| Модуль | Кейсов | Цель Sprint 3 | Цель Sprint 4 |
|---|---|---|---|
| orchestrator | 11 | route() полностью, handle() базовые | handle() edge cases, journal hooks |
| llm_client | 13 | chat + fallback + _client_for | streaming, _chat_web, reasoning_content edge |
| journal_recorder | 10 | before/after_tool_call | shadow store, retention, replay |
| memory_facade | 10 | initialize + search basic | dual-write, AGE, analytics |

## Что НЕ покрыто (намеренно)

- **`src/main.py` (2640 LOC, 86 эндпоинтов)** — после декомпозиции
  (рекомендация 1, Sprint 1.D). Каждый эндпоинт получит свой тест через
  `TestClient(app)` с моками зависимостей.
- **`src/loop/controller.py`** — нужен e2e тест с реальным LoopSpec
  и моком LLM, который возвращает tool_calls.
- **`src/db/*` (PostgreSQL pool, AGE, CDC)** — нужны контейнерные тесты
  с testcontainers-python или встроенным `pgserver` (есть в requirements.txt).
- **`src/mcp_servers/*` (37 серверов)** — каждый MCP требует
  интеграционного теста с реальным subprocess и моками filesystem.
- **WebSocket `/ws`** — нужен Playwright-тест (запуск браузера, открыть
  чат, отправить сообщение, дождаться стрима токенов).

## Известные проблемы

См. `tests/README.md` → раздел «Известные ограничения». Главные:

1. **`test_journal_recorder.py::test_inverse_spec_*`** — могут падать, если
   `before_tool_call` использует `os.path.realpath` и не находит файл.
   Решение: пометить `@pytest.mark.skip(reason="shadow store path")` и
   завести issue для починки.

2. **`test_llm_client.py::test_should_fallback_on_403/429`** — требуют
   `openai` пакет установленным. Если в окружении нет `openai` — тесты
   упадут с `ImportError`. Решение: пометить `@pytest.importorskip("openai")`.

3. **`test_memory_facade.py::test_initialize_with_pg_pool`** — патчит
   `src.db.pool.PgPool`, но `Memory._init_postgres` может импортировать
   `psycopg` на верхнем уровне. Если psycopg не установлен — падает с
   `ImportError`. Решение: установить `psycopg[binary]` в тестовое
   окружение или `@pytest.mark.skipif(not has_psycopg)`.

## Статус после Sprint 3

| Приоритет | Выполнено | В работе | Не начато |
|---|---|---|---|
| P0 | 2 (профили, док-ция) | 1 (main.py декомпозиция) | 0 |
| P1 | 5 (pre-commit, assert, mypy, tests каркас, requirements pinned) | 0 | 0 |
| P2 | 0 | 0 | 6 |
| **ИТОГО** | **7** | **1** | **6** |

Проект готов к production-deploy **после Sprint 4-5 (P2)**: контейнеризация,
SECURITY.md, logging, mcp 1.x контракт-тест, cleanup legacy, unified
feature skeleton.

## Связанные документы

- `tests/README.md` — детальное описание тестов
- Sprint 1 patch: `docs/ARCHIVES-DIFF.md`, `docs/MAIN-PY-DECOMPOSITION-PLAN.md`
- Sprint 2 patch: `.github/workflows/{typecheck,tests}.yml`, `.pre-commit-config.yaml`, `mypy.ini`
- Технический отчёт: `llm-agent-archives-analysis.pdf`
