# Sprint 2 Patch — llm-agent (P1: Quality Gate)

> Применяется поверх финальной сборки `llm-agent-final-2026-09-25-3`
> после применения Sprint 1 patch. Содержит конфиги и патчи для
> рекомендаций 4, 5, 6, 7 (каркас), 8.

## Что в патче

```
sprint2-patch/
├── .github/
│   └── workflows/
│       ├── typecheck.yml       ← рекомендация 6: mypy в CI
│       └── tests.yml           ← рекомендация 7 (каркас): pytest matrix 3.11/3.12
├── .pre-commit/
│   └── bandit.yaml             ← конфиг для bandit (исключения путей)
├── .pre-commit-config.yaml     ← рекомендация 4: pre-commit hooks
├── mypy.ini                    ← рекомендация 6: mypy config с gradual strict
├── requirements-dev.txt        ← рекомендация 4: dev-зависимости (ruff, bandit, mypy, pytest...)
├── requirements.pinned.txt     ← рекомендация 8: requirements.txt с ~= вместо >=
├── patches/
│   └── 0005-replace-assert-with-raise.patch   ← рекомендация 5: assert → raise
├── scripts/
│   ├── check_no_new_noqa.py    ← локальный хук: запрет новых # noqa
│   └── check_no_todo.py        ← локальный хук: запрет TODO в src/
├── SPRINT-ROADMAP.xlsx         ← обновлённый трекер (статусы Sprint 1+2)
└── README.md                   ← этот файл
```

## Порядок применения

```bash
# 0. Если ещё не применили Sprint 1 — примените сначала его:
unzip /path/to/llm-agent-final-sprint1-patch.zip -d /path/to/llm-agent/

# 1. Применить Sprint 2 патч поверх:
unzip /path/to/llm-agent-final-sprint2-patch.zip -d /path/to/llm-agent/

# 2. Установить pre-commit:
cd /path/to/llm-agent
pip install pre-commit
pre-commit install
pre-commit install --hook-type pre-push

# 3. Сгенерировать baseline для # noqa (первый запуск):
python scripts/gen_noqa_baseline.py > .pre-commit/noqa-baseline.txt
# (этот скрипт нужно написать; см. ниже)

# 4. Применить патч assert → raise:
git apply patches/0005-replace-assert-with-raise.patch
# Проверить: git diff src/llm_client.py src/mcp_servers/lsp/client.py

# 5. Заменить requirements.txt на requirements.pinned.txt:
cp requirements.txt requirements.txt.bak
cp requirements.pinned.txt requirements.txt
pip install -r requirements.txt   # проверить сходимость

# 6. Прогнать pre-commit по всем файлам (первый прогон):
pre-commit run --all-files
# Ожидается: ruff может что-то поправить (auto-fix), придётся перетейджить
```

## Риски и что проверять после применения

### Pre-commit hooks

- **ruff --fix** может отформатировать много файлов. Запустите
  `pre-commit run --all-files` на отдельной ветке, посмотрите
  `git diff`, и если изменений слишком много — настройте
  `ruff.toml` (создать отдельно) с нужными правилами.
- **bandit** может ругаться на `subprocess.run` в `run.py` и
  `install.py` — в `bandit.yaml` они уже исключены через `exclude_dirs`.
- **pip-audit** (или `uv-lock`) — если используете только pip, без uv,
  замените hook на pip-audit (см. комментарии в `.pre-commit-config.yaml`).

### mypy

- **First run будет non-blocking** — `continue-on-error: true` в
  `typecheck.yml` (раскомментировано). Первые 4 недели mypy будет
  только подсвечивать, не блокировать PR.
- **После 4 недель зелёного** — закомментируйте `continue-on-error: true`,
  mypy станет обязательным gate.
- **Strict-режим** включён только для `src/core/`, `src/loop/`, `src/journal/`
  и `src/memory/base` / `src/memory/facade` — критичных подсистем.
  Остальное проверяется в relaxed режиме.

### Патч assert → raise

- **3 файла** изменяются: `src/llm_client.py`, `src/mcp_servers/lsp/client.py`
  (тест `harness/tests/test_scenarios.py` не трогаем — там assert OK).
- **Smoke-test после применения**:
  ```bash
  # Запустить сервер, открыть чат, отправить сообщение
  python run.py
  # Если LLM-провайдер не настроен — клиент должен выдать понятное
  # RuntimeError, а не падать с AssertionError
  ```
- **Граничный случай**: `src/llm_client.py:184` — `assert last_exc is not None`
  стоял после retry-цикла. Если attempts[] пуст (не должно случаться), код
  падал бы с `AssertionError`. Теперь будет `RuntimeError` с понятным
  сообщением — это исправление наблюдаемости, а не behavior change.

### Pinned requirements

- **mcp~=1.1.3** — эквивалентно `>=1.1.3,<2.0` (compatible release
  для major.minor). Проверьте, что `mcp` установлен правильной версии:
  ```bash
  pip show mcp | grep Version
  # Должно быть 1.1.x (не 2.0+)
  ```
- **fastapi~=0.115.0** — разрешает патчи 0.115.x, но не 0.116+.
  FastAPI редко ломает в patch-релизах, но 0.116 может изменить API.
- **psycopg[binary,pool]~=3.2.0** — async API стабилен с 3.2,
  но 3.3 может изменить pool-конфиг.

## Что НЕ вошло в Sprint 2

- **Тесты на orchestrator/llm_client/journal/memory** (рекомендация 7) —
  только каркас workflow готов. Написание тестов — Sprint 3.
- **Декомпозиция src/main.py** (рекомендация 1) — продолжается, см.
  `MAIN-PY-DECOMPOSITION-PLAN.md` из Sprint 1 patch.
- **Все P2 задачи** (контейнеризация, SECURITY.md, logging, mcp 1.x тест) —
  Sprint 4-5.

## Что нужно сделать вручную

1. **Написать `scripts/gen_noqa_baseline.py`** — простая утилита, которая
   обходит `src/` и выводит `file:line` для каждой строки с `# noqa`.
   Текущие 106 строк — baseline.
2. **Создать `ruff.toml`** в корне репозитория (если хочется настроить
   правила ruff отдельно от значений по умолчанию).
3. **Добавить `CODECOV_TOKEN` в GitHub secrets** — для загрузки coverage
   отчёта в codecov.io (опционально, можно убрать шаг из workflow).
4. **Прогнать `pip install -r requirements.pinned.txt` на CI-матрице
   Python 3.11/3.12** — убедиться, что все версии сходятся.

## Связанные документы

- `SPRINT-ROADMAP.xlsx` — обновлённый трекер (P0: 2/3 выполнено, P1: 4/5 готово)
- Sprint 1 patch: `docs/ARCHIVES-DIFF.md`, `docs/MAIN-PY-DECOMPOSITION-PLAN.md`
- Технический отчёт: `llm-agent-archives-analysis.pdf`
