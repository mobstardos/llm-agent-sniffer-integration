# Sprint 4-5 Patch — llm-agent (P2: Maturity)

> Финальный патч в дорожной карте. Закрывает все 6 P2-рекомендаций.
> Применяется поверх Sprint 1 + Sprint 2 + Sprint 3.

## Что в патче

```
sprint4-5-patch/
├── .github/
│   └── SECURITY.md             ← рек. 11: responsible disclosure
├── .dockerignore               ← рек. 10: исключения для Docker build
├── Dockerfile                  ← рек. 10: multi-stage build (builder + runtime)
├── docker-compose.patch.yml    ← рек. 10: сервис llm-agent + volumes + healthcheck
├── features/
│   └── _template/              ← рек. 13: эталонный feature-скелетон
│       ├── feature.yaml        ← манифест (id, requires, api_router, ui_tab)
│       ├── api.py              ← create_router() → APIRouter (FastAPI)
│       ├── ui.js               ← IIFE, идемпотентная, mount в settings
│       └── README.md           ← как создать новую фичу, антипаттерны
├── patches/
│   └── 0012-print-to-logging.patch  ← рек. 12: 1 правка + ruff.toml
├── scripts/
│   └── move_legacy_prompts.sh  ← рек. 9: auto git mv 37 orphan prompt files
├── tests/
│   └── test_mcp_1x_contract.py ← рек. 14: 8 кейсов контракта mcp 1.x
├── SPRINT-ROADMAP.xlsx         ← обновлённый: P0 2/3, P1 5/5, P2 6/6 готово
└── README.md                   ← этот файл
```

## Что закрывает патч

| # | Реком. | Что сделано |
|---|---|---|
| 9 | Перенос legacy | `scripts/move_legacy_prompts.sh` — автоматический git mv 37 orphan `*_agent.py` из `src/prompts/` в `attic/prompts-legacy/` с обновлением imports в `attic/agents-legacy/*.py`. Поддержка `--dry-run`. |
| 10 | Контейнеризация | `Dockerfile` (multi-stage: builder+runtime, python:3.12-slim, USER llmagent, HEALTHCHECK), `.dockerignore`, `docker-compose.patch.yml` (сервис llm-agent с depends_on PG/AGE/Kafka, volumes для data/logs/shadows, journald logging, resource limits). |
| 11 | SECURITY.md | `.github/SECURITY.md` — поддерживаемые версии, 3 канала связи (email/GitHub Security Advisories/PGP), тайм-лайны response, угрожающая модель проекта (debug-MCP exec, file sandbox, shell, browser extension), hardening-чеклист для production (11 пунктов), safe harbor. |
| 12 | print → logging | `patches/0012-print-to-logging.patch` — 1 правка в `src/mcp_servers/debug/server.py` (cProfile tracer) + `ruff.toml` с правилом T20 (flake8-print) и per-file-ignores для CLI-модулей. **Важное открытие**: при детальном анализе оказалось, что server-код УЖЕ использует `logger.*()` — из 452 print() только 1 в реальном серверном коде. Обновлённый отчёт в комментарии патча. |
| 13 | Feature skeleton | `features/_template/{feature.yaml, api.py, ui.js, README.md}` — эталонный скелетон с подробной инструкцией "как создать новую фичу за 7 шагов", антипаттернами, тестовым шаблоном. Совпадает с контрактом `src/core/features.py:FeatureLoader`. |
| 14 | mcp 1.x contract test | `tests/test_mcp_1x_contract.py` — 8 кейсов: `test_mcp_version_is_1x` (fail при мажорной 2.0), `test_uses_mcp_1x_decorators` (AST analysis 37 серверов), `test_no_mcp_2x_api_usage` (no FastMCP), `test_imports_from_mcp_server_lowlevel` (no mcp.server.fastapi), `test_all_mcp_servers_have_server_py`, `test_all_mcp_servers_have_init_py`. |

## Порядок применения

```bash
# 0. Предполагается, что Sprint 1, 2, 3 патчи уже применены.
unzip /path/to/llm-agent-final-sprint1-patch.zip -d /path/to/llm-agent/
unzip /path/to/llm-agent-final-sprint2-patch.zip -d /path/to/llm-agent/
unzip /path/to/llm-agent-final-sprint3-patch.zip -d /path/to/llm-agent/

# 1. Распаковать Sprint 4-5:
unzip /path/to/llm-agent-final-sprint4-5-patch.zip -d /path/to/llm-agent/

# 2. Рекомендация 9 — перенос legacy prompts:
cd /path/to/llm-agent
bash scripts/move_legacy_prompts.sh --dry-run   # посмотреть, что будет
bash scripts/move_legacy_prompts.sh              # применить
git diff --stat                                  # проверить изменения
# Прогнать smoke-тест:
python run.py
# Если всё ОК — закоммитить:
git add -A && git commit -m 'refactor: move 37 orphan prompt files to attic/prompts-legacy/'

# 3. Рекомендация 10 — контейнеризация:
#    (если нет .env — создать из deploy/env.example)
cp deploy/env.example .env  # и заполнить секреты

# Сборка образа (5-15 минут):
docker build -t llm-agent:latest .

# Запуск через docker-compose (поднимет всё: PG, AGE, Kafka, llm-agent):
docker compose -f docker-compose.yml -f docker-compose.patch.yml up -d

# Проверка:
docker compose ps                          # все сервисы healthy?
curl http://127.0.0.1:8000/api/db/health   # должен вернуть 200 + {"status": "ok"}

# 4. Рекомендация 11 — SECURITY.md уже в .github/, ничего делать не нужно.
#    Заполнить email/PGP-key в .github/SECURITY.md (см. "Контакт" внизу файла).

# 5. Рекомендация 12 — print → logging:
git apply patches/0012-print-to-logging.patch
# Создать ruff.toml в корне:
# (часть патча — см. содержимое patches/0012-print-to-logging.patch)
cat ruff.toml  # проверить, что создан
# Прогнать ruff с новым правилом:
ruff check src/  # должен показать 0 ошибок (CLI-модули в per-file-ignores)

# 6. Рекомендация 13 — features/_template/ уже на месте, ничего делать не нужно.
#    Для создания новой фичи — см. features/_template/README.md

# 7. Рекомендация 14 — mcp 1.x контракт-тест:
pytest tests/test_mcp_1x_contract.py -v
# Ожидается: все 8 кейсов зелёные (если mcp 1.x установлен)
```

## Финальный статус проекта после всех 5 спринтов

| Приоритет | Выполнено | В работе | Не начато |
|---|---|---|---|
| **P0** | 2 (профили, док-ция) | 1 (main.py декомпозиция — 2-3 спринта) | 0 |
| **P1** | 5/5 ✓ (pre-commit, assert, mypy, tests, requirements) | 0 | 0 |
| **P2** | 6/6 ✓ (legacy, Docker, SECURITY, print, skeleton, mcp test) | 0 | 0 |
| **ИТОГО** | **13/14** (93%) | 1 | 0 |

**Один открытый пункт — рекомендация 1 (декомпозиция `src/main.py`)**.
Подробный план — в `docs/MAIN-PY-DECOMPOSITION-PLAN.md` из Sprint 1 patch.
Рефакторинг займёт 2-3 спринта, но это не блокирует production-deploy.

## Production-readiness чеклист

После применения всех 5 патчей проект готов к production-deploy:

- [x] **Профили восстановлены** (Sprint 1)
- [x] **Документация разницы архивов готова** (Sprint 1)
- [x] **Pre-commit hooks** (bandit/ruff/pip-audit/forbid-noqa/forbid-todo) (Sprint 2)
- [x] **Assert заменены на raise** (Sprint 2)
- [x] **mypy gate в CI** (gradual, strict для core/loop/journal/memory) (Sprint 2)
- [x] **pytest workflow** с coverage и matrix 3.11/3.12 (Sprint 2)
- [x] **Pinned версии критичных пакетов** (mcp, fastapi, pydantic, psycopg, openai, httpx, uvicorn) (Sprint 2)
- [x] **44 unit-теста** (orchestrator, llm_client, journal, memory) (Sprint 3)
- [x] **Legacy перенесены в attic/** (37 orphan prompts) (Sprint 4)
- [x] **Docker-контейнер для основного приложения** (multi-stage, healthcheck) (Sprint 4)
- [x] **SECURITY.md с responsible disclosure** (Sprint 5)
- [x] **print() → logging** (1 правка + ruff rule T20 как guard) (Sprint 5)
- [x] **Эталонный feature-скелетон** с инструкцией (Sprint 4-5)
- [x] **mcp 1.x контракт-тест** (8 кейсов AST analysis 37 серверов) (Sprint 5)
- [ ] **Декомпозиция src/main.py** (Sprint 1-3 рефакторинга — в работе)

## Финальная оценка

Проект **готов к выходу из alpha-стадии** в production. Поддерживается:
- Multi-instance deployment через nginx (sticky sessions)
- Docker-compose (полная инфра: PG+pgvector, AGE, Kafka, llm-agent)
- Systemd unit для bare-metal deploy
- Браузерное расширение (Chromium/Firefox с AMO-подписью)
- Observability: Prometheus metrics, journal event sourcing
- Security: approval gate, HITL, sandboxing, audit log
- Quality gate: pre-commit + mypy + pytest + mcp contract test

## Связанные документы

- `SPRINT-ROADMAP.xlsx` — финальный статус всех 14 задач
- Sprint 1 patch: `docs/{ARCHIVES-DIFF.md, MAIN-PY-DECOMPOSITION-PLAN.md}`
- Sprint 2 patch: `.github/workflows/{typecheck,tests}.yml`, `.pre-commit-config.yaml`, `mypy.ini`
- Sprint 3 patch: `tests/{conftest,test_orchestrator,test_llm_client,test_journal_recorder,test_memory_facade}.py`
- Технический отчёт: `llm-agent-archives-analysis.pdf`
