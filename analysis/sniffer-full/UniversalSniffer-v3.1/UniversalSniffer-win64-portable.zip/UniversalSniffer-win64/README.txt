﻿Universal Sniffer 3.1 — портативная сборка для Windows (x64)
================================================================

ЧТО ЭТО
  Прозрачный TCP-прокси сниффер с веб-панелью: перехватывает трафик между
  клиентами (АЗС) и сервером, распознаёт протоколы (RemoteServer TCP, Thrift
  RPC, HTTP/JSON, Modbus), пишет JSONL / SQLite / PCAP / CSV и поднимает
  тревоги по правилам.

КАК ЗАПУСТИТЬ
  1. Распакуйте архив ЦЕЛИКОМ в любую папку (например C:\UniversalSniffer).
  2. Запустите UniversalSniffer.exe — откроется консоль и браузер с панелью.
     - Если SmartScreen предупреждает: "Подробнее" -> "Выполнить в любом случае".
  3. Веб-панель: http://127.0.0.1:9500/  (порт меняется в config.json)

  Запасной способ: двойной клик по UniversalSniffer.bat.

СЛУЖБА WINDOWS (АВТОЗАПУСК)
  Хотите, чтобы сниффер стартовал вместе с Windows и работал без окна —
  установите его службой:

     service.bat install        (права администратора запросятся сами)

  Другие команды: service.bat start / stop / restart / status / remove.
  То же самое из командной строки:

     UniversalSniffer.exe --service install
     UniversalSniffer.exe --service start
     UniversalSniffer.exe --service restart     (после правки config.json)

  Служба стартует при загрузке Windows и сама перезапускается при сбоях.
  Логи службы: capture\service.log. Панель: http://127.0.0.1:9500/

НАСТРОЙКА ПОРТОВ
  По умолчанию сниффер слушает 9000 и 9010 и перенаправляет трафик на
  127.0.0.1:9001 и 127.0.0.1:9011 (нейтральные порты для универсального
  мониторинга).

  Свои порты — три способа:
    1) config.json рядом с exe (после правки — перезапуск, для службы
       service.bat restart):
         "ports": [
           {"listen": 3003,  "target_host": "127.0.0.1", "target_port": 3004,
            "name": "RemoteServer TCP", "parser": "auto"},
           {"listen": 10010, "target_host": "127.0.0.1", "target_port": 10011,
            "name": "Thrift RPC", "parser": "auto"}
         ],
         "web": {"enabled": true, "host": "0.0.0.0", "port": 9500}
    2) командной строкой:
         UniversalSniffer.exe --ports 3003:3004,10010:10011 --target-host 10.0.0.5
       (формат: слушать:цель; если цель не указана — порт+1)
    3) порт панели:  UniversalSniffer.exe --web-port 8080

  Сценарий АЗС (RemoteServer переехал на 3004/10011, АЗС стучатся на старые
  3003/10010): запустите с --ports 3003:3004,10010:10011 — см. пункт 2.

ГДЕ ЧЕГО ИЩЕТСЯ (рядом с exe)
  config.json      — настройки (порты, панель, экспорт, тревоги)
  service.bat      — управление службой Windows
  capture\         — traffic.jsonl, traffic.db (SQLite), traffic.pcap (Wireshark),
                     reports\ (CSV), clients\ (логи по клиентам), service.log
  app\plugins\    — ваши .py-плагины парсеров (шаблон в app/README.md)
  app\            — исходный код (можно запускать и обычным Python 3.9+)

КОМАНДЫ
  UniversalSniffer.exe --help            все параметры
  UniversalSniffer.exe --make-config my.json   шаблон конфига
  UniversalSniffer.exe --check-config    проверка конфига
  UniversalSniffer.exe --service ...     служба Windows (см. выше)

СОСТАВ
  runtime\ — официальный Python 3.11.9 (Windows embeddable, python.org),
  изменений в интерпретаторе нет. app\ — исходники сниффера (стандартная
  библиотека, сторонних зависимостей нет). UniversalSniffer.exe — лаунчер,
  который запускает runtime\python.exe app\sniffer.py.

ПРИМЕЧАНИЕ
  Для перехвата портов на сервере уже должен слушать целевой сервис на
  портах-преемниках (например 3004/10011) — иначе сниффер не сможет передать
  ему трафик. Останавливать клиентов (АЗС) на время переключения не нужно.
