@echo off
cd /d "%~dp0"
set "USNIFF_ROOT=%~dp0"
if not exist "runtime\python.exe" (echo Не найден runtime\python.exe - распакуйте архив целиком & pause & exit /b 1)
"runtime\python.exe" "app\sniffer.py" --open-browser %*
pause
