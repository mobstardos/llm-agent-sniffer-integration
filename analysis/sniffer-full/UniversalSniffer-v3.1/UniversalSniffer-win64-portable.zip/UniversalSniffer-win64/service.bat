@echo off
cd /d "%~dp0"
set "USNIFF_ROOT=%~dp0"
set "ACTION=%~1"
if "%ACTION%"=="" (
  echo Управление службой UniversalSniffer
  echo Использование: service.bat install^|remove^|start^|stop^|restart^|status
  pause
  exit /b 1
)
if not exist "runtime\python.exe" (echo Не найден runtime\python.exe - распакуйте архив целиком & pause & exit /b 1)
net session >nul 2>&1
if errorlevel 1 (
  echo Запрашиваю права администратора...
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -ArgumentList '%ACTION%' -Verb RunAs"
  exit /b
)
"runtime\python.exe" "app\sniffer.py" --service %ACTION%
echo.
pause
